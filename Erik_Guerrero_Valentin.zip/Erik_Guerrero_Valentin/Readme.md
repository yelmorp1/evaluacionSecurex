# FRONTEND
* Angular v10

# BACKEND
* Spring Boot + JWT + PostgresSQL
* Database:
- name: pruebajwt
- user: postgres
- password: postgres

* Usuario de prueba:
- Usuario: eguerrero
- Password: 123456